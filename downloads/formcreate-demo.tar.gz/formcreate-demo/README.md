# formcreate-demo

一个可运行的 Vue 3 + Vite + Element Plus + form-create 示例项目。

## 功能点

- 动态表单渲染
- 部门下拉从外部接口获取
- 请假类型从字典接口获取
- 选人组件通过 API 远程搜索
- 按部门联动加载审批人
- 子表单/明细行录入
- 提交后展示 payload

## 启动

```bash
npm install
npm run dev
```

## 说明

为了方便直接运行，项目里使用 `axios` 拦截器模拟接口返回，不依赖真实后端。
