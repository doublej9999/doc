<template>
  <div class="page">
    <div class="card">
      <div class="header">
        <h1>form-create 可运行示例</h1>
        <p>演示动态表单、外部数据获取、选人 API 搜索、子表单明细与提交结果回显。</p>
      </div>

      <form-create v-model:api="fApi" :rule="rule" :option="option" />

      <pre class="result">{{ JSON.stringify(submitResult, null, 2) }}</pre>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import axios from 'axios'

const fApi = ref(null)
const submitResult = ref({ message: '提交后，这里会显示 payload' })

const rule = ref([
  {
    type: 'input',
    field: 'title',
    title: '申请标题',
    value: '',
    props: { placeholder: '请输入申请标题' },
    validate: [{ required: true, message: '申请标题必填', trigger: 'blur' }]
  },
  {
    type: 'select',
    field: 'deptId',
    title: '所属部门',
    value: '',
    options: [],
    props: {
      placeholder: '请选择部门',
      filterable: true,
      clearable: true
    },
    on: {
      change: async value => {
        fApi.value.setValue('assigneeId', '')
        fApi.value.updateRule('assigneeId', { options: [] })
        if (!value) return

        const res = await axios.get('/api/user/search', { params: { deptId: value } })
        const options = (res.data?.data || []).map(user => ({
          label: `${user.name} / ${user.mobile} / ${user.deptName}`,
          value: user.id
        }))
        fApi.value.updateRule('assigneeId', { options })
      }
    },
    validate: [{ required: true, message: '请选择部门', trigger: 'change' }]
  },
  {
    type: 'select',
    field: 'leaveType',
    title: '请假类型',
    value: '',
    options: [],
    props: {
      placeholder: '请选择请假类型',
      clearable: true
    },
    validate: [{ required: true, message: '请选择请假类型', trigger: 'change' }]
  },
  {
    type: 'select',
    field: 'assigneeId',
    title: '审批人',
    value: '',
    options: [],
    props: {
      placeholder: '输入姓名/手机号远程搜索审批人',
      filterable: true,
      remote: true,
      clearable: true,
      remoteMethod: async keyword => {
        const deptId = fApi.value.getValue('deptId')
        const res = await axios.get('/api/user/search', {
          params: { keyword, deptId }
        })
        const options = (res.data?.data || []).map(user => ({
          label: `${user.name} / ${user.mobile} / ${user.deptName}`,
          value: user.id
        }))
        fApi.value.updateRule('assigneeId', { options })
      }
    },
    validate: [{ required: true, message: '请选择审批人', trigger: 'change' }]
  },
  {
    type: 'select',
    field: 'ccUserIds',
    title: '抄送人',
    value: [],
    options: [],
    props: {
      placeholder: '输入关键词远程搜索抄送人',
      filterable: true,
      remote: true,
      multiple: true,
      collapseTags: true,
      clearable: true,
      remoteMethod: async keyword => {
        const res = await axios.get('/api/user/search', { params: { keyword } })
        const options = (res.data?.data || []).map(user => ({
          label: `${user.name} / ${user.deptName}`,
          value: user.id
        }))
        fApi.value.updateRule('ccUserIds', { options })
      }
    }
  },
  {
    type: 'datePicker',
    field: 'leaveRange',
    title: '请假时间',
    value: [],
    props: {
      type: 'datetimerange',
      startPlaceholder: '开始时间',
      endPlaceholder: '结束时间',
      valueFormat: 'YYYY-MM-DD HH:mm:ss'
    },
    validate: [{ required: true, message: '请选择请假时间', trigger: 'change' }]
  },
  {
    type: 'input',
    field: 'reason',
    title: '请假原因',
    value: '',
    props: {
      type: 'textarea',
      rows: 4,
      placeholder: '请输入请假原因'
    },
    validate: [{ required: true, message: '请输入请假原因', trigger: 'blur' }]
  },
  {
    type: 'group',
    field: 'details',
    title: '补充明细',
    value: [
      { date: '', hours: 8, remark: '' }
    ],
    props: {
      addBtnText: '新增明细',
      rule: [
        {
          type: 'datePicker',
          field: 'date',
          title: '日期',
          props: {
            type: 'date',
            valueFormat: 'YYYY-MM-DD'
          }
        },
        {
          type: 'inputNumber',
          field: 'hours',
          title: '请假小时数',
          value: 8,
          props: { min: 1, max: 24 }
        },
        {
          type: 'input',
          field: 'remark',
          title: '备注',
          props: { placeholder: '请输入备注' }
        }
      ]
    }
  }
])

const option = ref({
  form: {
    labelWidth: '110px'
  },
  submitBtn: {
    text: '提交申请'
  },
  resetBtn: true,
  async onSubmit(formData) {
    const payload = {
      ...formData,
      startTime: formData.leaveRange?.[0] || '',
      endTime: formData.leaveRange?.[1] || ''
    }
    delete payload.leaveRange

    const res = await axios.post('/api/leave/apply', payload)
    submitResult.value = res.data?.data || payload
    ElMessage.success(res.data?.message || '提交成功')
  }
})

async function loadDeptOptions() {
  const res = await axios.get('/api/dept/list')
  const options = (res.data?.data || []).map(item => ({
    label: item.deptName,
    value: item.deptId
  }))
  fApi.value.updateRule('deptId', { options })
}

async function loadLeaveTypeOptions() {
  const res = await axios.get('/api/dict/options', {
    params: { dictType: 'leave_type' }
  })
  const options = (res.data?.data || []).map(item => ({
    label: item.label,
    value: item.value
  }))
  fApi.value.updateRule('leaveType', { options })
}

async function loadInitialUsers() {
  const res = await axios.get('/api/user/search', { params: { keyword: '' } })
  const options = (res.data?.data || []).map(user => ({
    label: `${user.name} / ${user.deptName}`,
    value: user.id
  }))
  fApi.value.updateRule('ccUserIds', { options })
}

onMounted(async () => {
  await loadDeptOptions()
  await loadLeaveTypeOptions()
  await loadInitialUsers()
})
</script>
