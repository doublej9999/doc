import axios from 'axios'

const deptList = [
  { deptId: 1, deptName: '技术部' },
  { deptId: 2, deptName: '产品部' },
  { deptId: 3, deptName: '运营部' }
]

const users = [
  { id: 'u1001', name: '张三', mobile: '13800138000', deptId: 1, deptName: '技术部' },
  { id: 'u1002', name: '李四', mobile: '13800138001', deptId: 1, deptName: '技术部' },
  { id: 'u1003', name: '王五', mobile: '13800138002', deptId: 2, deptName: '产品部' },
  { id: 'u1004', name: '赵六', mobile: '13800138003', deptId: 3, deptName: '运营部' },
  { id: 'u1005', name: '陈晨', mobile: '13800138004', deptId: 2, deptName: '产品部' }
]

const dictMap = {
  leave_type: [
    { label: '事假', value: 'personal_leave' },
    { label: '病假', value: 'sick_leave' },
    { label: '年假', value: 'annual_leave' }
  ]
}

axios.interceptors.request.use(async config => {
  const { url, params, method } = config

  if (method?.toLowerCase() === 'get' && url === '/api/dept/list') {
    return Promise.reject({
      __mock: true,
      response: { data: { code: 200, data: deptList } }
    })
  }

  if (method?.toLowerCase() === 'get' && url === '/api/dict/options') {
    return Promise.reject({
      __mock: true,
      response: { data: { code: 200, data: dictMap[params?.dictType] || [] } }
    })
  }

  if (method?.toLowerCase() === 'get' && url === '/api/user/search') {
    const keyword = (params?.keyword || '').trim()
    const deptId = params?.deptId
    const list = users.filter(user => {
      const matchKeyword = !keyword || user.name.includes(keyword) || user.mobile.includes(keyword)
      const matchDept = !deptId || user.deptId === Number(deptId)
      return matchKeyword && matchDept
    })

    return Promise.reject({
      __mock: true,
      response: { data: { code: 200, data: list } }
    })
  }

  if (method?.toLowerCase() === 'get' && url?.startsWith('/api/user/detail/')) {
    const id = url.split('/').pop()
    const user = users.find(item => item.id === id)
    return Promise.reject({
      __mock: true,
      response: { data: { code: 200, data: user || null } }
    })
  }

  if (method?.toLowerCase() === 'post' && url === '/api/leave/apply') {
    return Promise.reject({
      __mock: true,
      response: {
        data: {
          code: 200,
          message: '提交成功',
          data: config.data ? JSON.parse(config.data) : {}
        }
      }
    })
  }

  return config
})

axios.interceptors.response.use(
  response => response,
  error => {
    if (error.__mock) {
      return Promise.resolve(error.response)
    }
    return Promise.reject(error)
  }
)
