import { createApp } from 'vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import formCreate from '@form-create/element-ui'
import App from './App.vue'
import './mock'
import './style.css'

const app = createApp(App)
app.use(ElementPlus)
app.use(formCreate)
app.mount('#app')
